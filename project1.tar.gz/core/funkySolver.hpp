#ifndef FUNKYSOLVER_HPP
#define FUNKYSOLVER_HPP
#include "MazeSolver.hpp"
#include "Maze.hpp"
#include "MazeSolution.hpp"
#include "MazeFactory.hpp"
#include <random>
#include <memory>
#include <vector>

using namespace std;
class funkySolver: public MazeSolver
{
public:
	funkySolver();
 virtual void solveMaze(const Maze& maze, MazeSolution& mazeSolution) ;
private:
	random_device device;
   	default_random_engine engine{device()};
    vector<vector<bool>> fillStates(int W, int H);
    void make(const Maze& maze, MazeSolution& mazeSolution,int x,int y);
    int RndmArray(const Maze& maze, int x, int y ,MazeSolution& mazeSolution);
	vector<vector<bool>> arr;


	//int RndmArray(Maze& maze, int x, int y);//picks random direction
};
#endif