
#include <ics46/factory/DynamicFactory.hpp>
#include "funkySolver.hpp"
#include <iostream>
#include "MazeSolver.hpp"
#include "MazeSolution.hpp"
#include "Maze.hpp"
#include "Direction.hpp"
#include <random>
#include <vector>






ICS46_DYNAMIC_FACTORY_REGISTER(MazeSolver, funkySolver, "FUNKY_SOlVER(Rquired)");


funkySolver::funkySolver(){};



  vector<vector<bool>> funkySolver::fillStates(int W, int H)
  {
    	vector<vector<bool>> array(W, vector<bool> (H,false));
    	return array;
  }



int funkySolver::RndmArray(const Maze& maze, int x, int y,MazeSolution& mazeSolution)
{
	bool l= false;
	bool r= false;
	bool u = false;
	bool d = false;

	if(maze.wallExists( x, y,Direction::right) != true)
	{
		if(arr[x +1][y] == false)
		{
			if( x != mazeSolution.getEndingCell().first)
			{
				r = true;
			}
		}
	}
	if(maze.wallExists( x, y,Direction::left) != true)
	{
		if(arr[x -1][y] == false)
		{
			if(x != mazeSolution.getStartingCell().first)
			{
				l = true;
			}
		}
	}
	if(maze.wallExists( x, y,Direction::up) !=true)
	{
		if(arr[x ][y -1] == false)
		{
			if( y != mazeSolution.getStartingCell().second)
			{
				u =true;
			}
		}
	}
	if(maze.wallExists( x, y,Direction::down) !=true)
	{
		if(arr[x ][y +1] == false)
 		{
 			if( y != mazeSolution.getEndingCell().second)
			{
				d =true;
			}
		}
	}

	if (d == true)
	{
		return 3;
	}
		if( r == true)
	{
		return 2;
	}
	if(u == true)
	{
		return 1;
	}
	if ( l == true)
	{
		return 4;
	}
	return -1;

}


  
    void funkySolver::make(const Maze& maze, MazeSolution& mazeSolution,int x,int y)
    {
    	if(mazeSolution.isComplete()==true)
    	{
    		return;
    	}

int cx =mazeSolution.getCurrentCell().first;
int cy =mazeSolution.getCurrentCell().second;
 arr[cx][cy]= true;

	int sx =x;
	int sy =y;


		while(  RndmArray(maze,mazeSolution.getCurrentCell().first,mazeSolution.getCurrentCell().second,mazeSolution)!= -1)
		{

			if(arr[cx][cy]==false)
				{
					arr[cx][cy]=true;
				}
		if(RndmArray(maze,cx,cy,mazeSolution)== 1 && y != 0 && maze.wallExists(cx,cy,Direction::up)==false )
		{

			if(y > mazeSolution.getStartingCell().second && arr[x][y-1]==false)
			{
									arr[cx][cy-1]=true;

							mazeSolution.extend(Direction::up);

			make(maze,mazeSolution,cx,cy-1);
			    	if(mazeSolution.isComplete()==true)
			break;
		}


			if(y != mazeSolution.getHeight())
			sy--;
		}
		else if(RndmArray(maze,cx,cy,mazeSolution)==2 && x != mazeSolution.getEndingCell().first && maze.wallExists(cx,cy,Direction::right)==false)
		{
			if(cx < mazeSolution.getEndingCell().first && arr[cx+1][cy]==false)
			{
			arr[cx+1][cy]=true;

			mazeSolution.extend(Direction::right);

			make(maze,mazeSolution,cx+1,cy);
			    	if(mazeSolution.isComplete()==true)
						break;
		}

			if(sx  != 0)
			sx++;
		}
		else if(RndmArray(maze, cx,cy,mazeSolution) ==3 && cy != mazeSolution.getEndingCell().second && maze.wallExists(cx,cy,Direction::down)==false)
		{ 
			if(y < mazeSolution.getEndingCell().second && arr[x][y+1]==false)
				{			
						arr[cx][cy+1]=true;

						mazeSolution.extend(Direction::down);

			make(maze,mazeSolution,cx,cy+1);    	
			if(mazeSolution.isComplete()==true)
					break;
}
			if(cy != 0)
			sy++;

		}
		else if(RndmArray(maze, cx,cy,mazeSolution)==4 && x > 0 && maze.wallExists(cx,cy,Direction::left)==false)
		{
			if(cx > 0  && arr[cx-1][cy]==false)
				{
					arr[cx-1][cy]=true;
								mazeSolution.extend(Direction::left);

			make(maze,mazeSolution,cx-1,cy);
			    	if(mazeSolution.isComplete()==true)
					break;
}
			if(cx != mazeSolution.getWidth()-1)
			sx--;

		}

    	mazeSolution.backUp();

	}



}


 void funkySolver::solveMaze(const Maze& maze, MazeSolution& mazeSolution) 
 {
 	 arr=  fillStates(mazeSolution.getEndingCell().first+1, mazeSolution.getEndingCell().second+1);
 	 int x= mazeSolution.getStartingCell().first;
 	 int y=mazeSolution.getStartingCell().second;
 	 make(maze,mazeSolution,x,y);

 }

