#include <ics46/factory/DynamicFactory.hpp>
#include "funky.hpp"
#include <iostream>
#include "Maze.hpp"
#include "Direction.hpp"
#include <random>
#include <vector>


ICS46_DYNAMIC_FACTORY_REGISTER(MazeGenerator, funky, "FUNKY(Rquired)");


funky::funky(){};


	bool funky::full(Maze &maze)
	{ 
		for(int x=0; x < maze.getWidth()-1; x ++)
		{
			for(int y = 0; y< maze.getHeight()-1; y++)
			{
				if(arr[x][y]== false)
				{
				
					return false;
				}
			}
		}
		if(tr > (maze.getWidth()*maze.getHeight()) -4)
		{
			return true;
		}
		return true;
	}

	int funky::Rndm()
	{
		uniform_int_distribution<int> distribution {1,4};
  		return distribution(engine);
	}

	int funky::RndmArray(Maze& maze, int x, int y)
	{
	
	bool l= false;
	bool r= false;
	bool u = false;
	bool d = false;


	if(x!=0)
	if ( arr[x-1][y]!=true && x > 0 )
	{
		l = true; //left cell is available
	}
	if(y != maze.getHeight()-1)
	if(  arr[x][y+1] !=true )
	{
		d = true;
	}
	if(y!=0) 
		if( arr[x][y-1]!=true && y >=0)
	{
		u= true;
	}
	if(x != maze.getWidth()-1)
	if( arr[x+1][y]!= true)
	{
		r=true;
	}

	if(arr[x][y]==false ||x> maze.getWidth() || y > maze.getHeight())
	{
		return -1;
	}

	if (l==false && r==false && u==false && d==false)//if(x==0 && arr[x-1][y]==true && x==maze.getHeight()&& arr[x][y+1] ==true && y==0 && arr[x][y-1]==true && y==maze.getWidth() && arr[x+1][y]== true)
	{
		return -1;
	}

 	bool flag = false;


	while(flag==false)
	{
   		uniform_int_distribution<int> distribution {1,4};
   		int k= distribution(engine);

		if(k==1)
		{
			if(u==true&&y>=0)
			{	
								flag= true;
								return 1;//up
			}
		}


		else if(k==2)
		{
			if(r==true)
			{
								flag= true;
								return 2;//right
			}
		}
		else if(k==3)
		{
			if(d==true )
			{

								flag= true;
								return 3;//down
			}
		}
		else if(k==4)
		{
			if(l==true&& x>=0)
			{
				flag= true;
								return 4;
			}
		}


 	 }
 	 return -1;
}


   vector<vector<bool>> funky::fillStates(int W, int H)
  {
    	vector<vector<bool>> array(W, vector<bool> (H,false));
    	return array;
   }


void funky::make(Maze& maze, int x, int y)
{
	 arr[x][y]= true;
	if(full(maze)==true)
	{
		return;
	}
	int sx =x;
	int sy =y;
	if(RndmArray(maze, sx,sy)== -1)
	{
		return;
	}

		while( RndmArray(maze,x,y) != -1 ){

			if(arr[x][y]==false)
				{
					arr[x][y]=true;
				}
		if(RndmArray(maze,x,y)== 1 && y != 0)
		{
			maze.removeWall(x,y,Direction::up);

			if(y-1 >=0)
			{
			make(maze,x,y-1);
			tr++;
		}
		else
			break;

			if(y != maze.getHeight())
			sy--;
		}
		else if(RndmArray(maze,x,y)==2 && x != maze.getWidth())
		{
			maze.removeWall(x,y,Direction::right);
			if(x+1 <= maze.getWidth())
			{
			make(maze,x+1,y);
			tr++;
		}
		else 
			break;

			if(x  != 0)
			sx++;
		}
		else if(RndmArray(maze, x,y) ==3 && y!=maze.getHeight())
		{
			maze.removeWall(x,y,Direction::down);
			if(y+1 <= maze.getHeight())
				{tr++;
			make(maze,x,y+1);}
		else
			break;

			if(y != 0)
			sy++;

		}
		else if(RndmArray(maze, x,y)==4 && x != 0)
		{
			maze.removeWall(x,y,Direction::left);
			if(x-1 >= 0)
				{tr++;
			make(maze,x-1,y);}
		else
			break;
			if(x != maze.getWidth())
			sx--;
		}


	}
}

	
void funky::generateMaze(Maze& maze)
{
	    arr=  fillStates(maze.getWidth(), maze.getHeight());
	    maze.addAllWalls();

	    	int x=0;
	    int y=0;
	    make(maze, x, y);	    

}
	