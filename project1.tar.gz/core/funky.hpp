#ifndef FUNKY_HPP
#define FUNKY_HPP
#include "MazeGenerator.hpp"
#include "Maze.hpp"
#include "MazeFactory.hpp"
#include <random>
#include <memory>
#include <vector>


using namespace std;


class funky: public MazeGenerator
{
public:
	funky();
	virtual void generateMaze(Maze& maze);

private:
	random_device device;
   	default_random_engine engine{device()};
    vector<vector<bool>> fillStates(int W, int H);
	bool full(Maze &maze);
	int Rndm();// 1 2 3 4
	int RndmArray(Maze& maze, int x, int y);//picks random direction
	void make(Maze& maze, int x, int y);
	vector<vector<bool>> arr;
	int tr=0;
};
#endif